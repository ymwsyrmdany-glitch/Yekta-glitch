package com.iranweapons;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3f;

@Environment(EnvType.CLIENT)
public class WeaponRenderer extends MobEntityRenderer<WeaponEntity, WeaponModel> {
    private final Identifier texture;
    private final float centerY;

    public WeaponRenderer(EntityRenderDispatcher dispatcher, WeaponModel model,
                          String textureName, float centerY) {
        super(dispatcher, model, 0.4F);
        this.texture = new Identifier(IranWeapons.MOD_ID, "textures/entity/" + textureName + ".png");
        this.centerY = centerY;
    }

    @Override
    public Identifier getTexture(WeaponEntity entity) {
        return this.texture;
    }

    @Override
    protected void setupTransforms(WeaponEntity entity, MatrixStack matrices,
                                   float animationProgress, float bodyYaw, float tickDelta) {
        super.setupTransforms(entity, matrices, animationProgress, bodyYaw, tickDelta);
        float pitch = MathHelper.lerp(tickDelta, entity.prevPitch, entity.pitch);
        matrices.translate(0.0D, this.centerY, 0.0D);
        matrices.multiply(Vec3f.POSITIVE_X.getDegreesQuaternion(-pitch));
        matrices.translate(0.0D, -this.centerY, 0.0D);
    }
}
