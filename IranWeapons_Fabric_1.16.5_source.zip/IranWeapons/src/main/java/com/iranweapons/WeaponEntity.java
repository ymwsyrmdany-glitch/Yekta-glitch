package com.iranweapons;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.control.LookControl;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.FlyingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;
import net.minecraft.world.explosion.Explosion;

/** Flying kamikaze entity: drone loiters, missiles wait; both dive on the nearest player. */
public class WeaponEntity extends FlyingEntity {
    private final WeaponConfig cfg;
    private boolean exploded = false;

    public WeaponEntity(EntityType<? extends WeaponEntity> type, World world, WeaponConfig cfg) {
        super(type, world);
        this.cfg = cfg;
        this.setPersistent();
        // keep our own pitch/yaw (vanilla look control would reset pitch to 0)
        this.lookControl = new LookControl(this) {
            @Override
            public void tick() {
            }
        };
    }

    public static DefaultAttributeContainer.Builder createAttributes(WeaponConfig cfg) {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, cfg.health)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, cfg.range);
    }

    @Override
    public boolean hasNoGravity() {
        return true;
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (source.isExplosive()) {
            return false; // no chain reactions between weapons
        }
        return super.damage(source, amount);
    }

    @Override
    protected void mobTick() {
        super.mobTick();

        PlayerEntity target = this.world.getClosestPlayer(
                this.getX(), this.getY(), this.getZ(), cfg.range, false);

        if (target != null) {
            double cx = this.getX();
            double cy = this.getY() + this.getHeight() * 0.5D;
            double cz = this.getZ();
            double dx = target.getX() - cx;
            double dy = (target.getY() + target.getHeight() * 0.5D) - cy;
            double dz = target.getZ() - cz;
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

            boolean blocked = (this.horizontalCollision || this.verticalCollision) && this.age > 20;
            if (dist < Math.max(2.0D, cfg.speed * 1.2D) || blocked) {
                this.explode();
                return;
            }

            double k = cfg.speed / Math.max(dist, 1.0E-4D);
            this.setVelocity(dx * k, dy * k, dz * k);

            double horiz = Math.sqrt(dx * dx + dz * dz);
            this.yaw = (float) (Math.atan2(dz, dx) * 57.29577951308232D) - 90.0F;
            this.pitch = (float) (-(Math.atan2(dy, horiz) * 57.29577951308232D));
            this.bodyYaw = this.yaw;
            this.headYaw = this.yaw;
        } else if (cfg.loiter) {
            // circle slowly while waiting for a target
            this.yaw += 3.0F;
            double r = Math.toRadians(this.yaw);
            double vy = this.horizontalCollision ? 0.25D : 0.0D;
            this.setVelocity(-Math.sin(r) * 0.25D, vy, Math.cos(r) * 0.25D);
            this.pitch = 0.0F;
            this.bodyYaw = this.yaw;
            this.headYaw = this.yaw;
        } else {
            this.setVelocity(Vec3d.ZERO);
        }
    }

    private void explode() {
        if (this.world.isClient || this.exploded) {
            return;
        }
        this.exploded = true;
        Explosion.DestructionType type = this.world.getGameRules().getBoolean(GameRules.DO_MOB_GRIEFING)
                ? Explosion.DestructionType.DESTROY
                : Explosion.DestructionType.NONE;
        this.world.createExplosion(this, this.getX(), this.getY() + this.getHeight() * 0.5D,
                this.getZ(), cfg.power, type);
        this.remove();
    }
}
