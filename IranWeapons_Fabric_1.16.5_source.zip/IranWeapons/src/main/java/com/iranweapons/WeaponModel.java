package com.iranweapons;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;

@Environment(EnvType.CLIENT)
public class WeaponModel extends EntityModel<WeaponEntity> {
    private final ModelPart body;

    public WeaponModel(float[][] cubes) {
        this.textureWidth = 128;
        this.textureHeight = 128;
        this.body = new ModelPart(this);
        this.body.setPivot(0.0F, 24.0F, 0.0F);
        for (float[] c : cubes) {
            // Java model space: y points down from the pivot (feet)
            this.body.setTextureOffset(0, (int) c[6])
                    .addCuboid(c[0], -(c[1] + c[4]), c[2], c[3], c[4], c[5]);
        }
    }

    @Override
    public void setAngles(WeaponEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay,
                       float red, float green, float blue, float alpha) {
        this.body.render(matrices, vertices, light, overlay, red, green, blue, alpha);
    }
}
