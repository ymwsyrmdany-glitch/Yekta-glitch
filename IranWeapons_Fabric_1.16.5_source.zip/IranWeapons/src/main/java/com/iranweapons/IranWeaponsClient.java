package com.iranweapons;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendereregistry.v1.EntityRendererRegistry;

@Environment(EnvType.CLIENT)
public class IranWeaponsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.INSTANCE.register(IranWeapons.SHAHED,
                (dispatcher, context) -> new WeaponRenderer(dispatcher,
                        new WeaponModel(WeaponModels.shahed()), "shahed136", 0.15F));
        EntityRendererRegistry.INSTANCE.register(IranWeapons.FATEH,
                (dispatcher, context) -> new WeaponRenderer(dispatcher,
                        new WeaponModel(WeaponModels.fateh()), "fateh110", 0.5F));
        EntityRendererRegistry.INSTANCE.register(IranWeapons.SHAHAB,
                (dispatcher, context) -> new WeaponRenderer(dispatcher,
                        new WeaponModel(WeaponModels.shahab()), "shahab3", 0.65F));
    }
}
