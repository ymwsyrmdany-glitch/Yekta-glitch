package com.iranweapons;

/** Cube lists: {x, y, z, sizeX, sizeY, sizeZ, textureV}. y = height above feet, nose = -Z. */
public final class WeaponModels {
    private WeaponModels() {}

    private static float[] c(float x, float y, float z, float sx, float sy, float sz, boolean accent) {
        return new float[]{x, y, z, sx, sy, sz, accent ? 64F : 0F};
    }

    public static float[][] shahed() {
        return new float[][]{
                c(-1.5F, 0F, -14F, 3F, 3F, 28F, false),
                c(-1F, 0.5F, -17F, 2F, 2F, 3F, true),
                c(-13F, 1F, 8F, 26F, 1F, 5F, false),
                c(-10F, 1F, 3F, 20F, 1F, 5F, false),
                c(-7F, 1F, -2F, 14F, 1F, 5F, false),
                c(-4F, 1F, -7F, 8F, 1F, 5F, false),
                c(-13F, 0F, 8F, 1F, 4F, 5F, true),
                c(12F, 0F, 8F, 1F, 4F, 5F, true),
                c(-3F, 1.25F, 14F, 6F, 0.5F, 0.5F, true),
                c(-0.25F, -1.5F, 14F, 0.5F, 6F, 0.5F, true)
        };
    }

    public static float[][] fateh() {
        return new float[][]{
                c(-2F, 6F, -18F, 4F, 4F, 36F, false),
                c(-1.5F, 6.5F, -22F, 3F, 3F, 4F, true),
                c(-0.75F, 7.25F, -25F, 1.5F, 1.5F, 3F, true),
                c(-0.5F, 10F, 10F, 1F, 5F, 8F, true),
                c(-0.5F, 1F, 10F, 1F, 5F, 8F, true),
                c(2F, 7.5F, 10F, 5F, 1F, 8F, true),
                c(-7F, 7.5F, 10F, 5F, 1F, 8F, true)
        };
    }

    public static float[][] shahab() {
        return new float[][]{
                c(-2.5F, 8F, -24F, 5F, 5F, 48F, false),
                c(-2F, 8.5F, -30F, 4F, 4F, 6F, true),
                c(-1F, 9.5F, -35F, 2F, 2F, 5F, true),
                c(-0.5F, 13F, 18F, 1F, 8F, 6F, true),
                c(-0.5F, 0F, 18F, 1F, 8F, 6F, true),
                c(2.5F, 10F, 18F, 8F, 1F, 6F, true),
                c(-10.5F, 10F, 18F, 8F, 1F, 6F, true)
        };
    }
}
