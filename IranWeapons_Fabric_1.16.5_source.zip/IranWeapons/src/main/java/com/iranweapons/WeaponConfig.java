package com.iranweapons;

public final class WeaponConfig {
    public final float width, height, health, power;
    public final double speed, range;
    public final boolean loiter;

    public WeaponConfig(float width, float height, float health, float power,
                        double speed, double range, boolean loiter) {
        this.width = width;
        this.height = height;
        this.health = health;
        this.power = power;
        this.speed = speed;
        this.range = range;
        this.loiter = loiter;
    }

    //                                              w     h    hp    power speed range loiter
    public static final WeaponConfig SHAHED = new WeaponConfig(1.4F, 0.5F, 8F,  4F,  0.5D, 64D,  true);
    public static final WeaponConfig FATEH  = new WeaponConfig(0.8F, 1.0F, 6F,  8F,  1.0D, 96D,  false);
    public static final WeaponConfig SHAHAB = new WeaponConfig(1.0F, 1.0F, 10F, 14F, 0.9D, 128D, false);
}
