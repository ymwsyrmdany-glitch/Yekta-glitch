package com.iranweapons;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class IranWeapons implements ModInitializer {
    public static final String MOD_ID = "iranweapons";

    public static EntityType<WeaponEntity> SHAHED;
    public static EntityType<WeaponEntity> FATEH;
    public static EntityType<WeaponEntity> SHAHAB;

    @Override
    public void onInitialize() {
        SHAHED = register("shahed136", WeaponConfig.SHAHED, 0xC4C4BE, 0x37373A);
        FATEH = register("fateh110", WeaponConfig.FATEH, 0xE4E4DE, 0x8C1E1E);
        SHAHAB = register("shahab3", WeaponConfig.SHAHAB, 0xCDCDC8, 0x2D2D30);
    }

    private static EntityType<WeaponEntity> register(String name, WeaponConfig cfg, int c1, int c2) {
        EntityType<WeaponEntity> type = Registry.register(
                Registry.ENTITY_TYPE,
                new Identifier(MOD_ID, name),
                FabricEntityTypeBuilder.<WeaponEntity>create(SpawnGroup.MISC,
                        (t, w) -> new WeaponEntity(t, w, cfg))
                        .dimensions(EntityDimensions.fixed(cfg.width, cfg.height))
                        .trackRangeBlocks(128)
                        .trackedUpdateRate(1)
                        .forceTrackedVelocityUpdates(true)
                        .fireImmune()
                        .build());
        FabricDefaultAttributeRegistry.register(type, WeaponEntity.createAttributes(cfg));
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, name + "_spawn_egg"),
                new SpawnEggItem(type, c1, c2, new Item.Settings().group(ItemGroup.MISC)));
        return type;
    }
}
