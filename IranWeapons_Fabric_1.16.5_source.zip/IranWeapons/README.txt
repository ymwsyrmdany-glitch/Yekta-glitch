Iran Weapons - Fabric 1.16.5 (Pojav Launcher)

ساخت فایل jar (بدون کامپیوتر، با GitHub):
1) در github.com حساب و یک repository جدید بسازید.
2) محتوای همین پوشه را در آن آپلود کنید (Add file > Upload files).
   اگر پوشهٔ .github آپلود نشد: Add file > Create new file،
   اسمش را  .github/workflows/build.yml  بگذارید و محتوای workflow-copy/build.yml را paste کنید.
3) تب Actions > اجرای build تمام شود (حدود ۳ تا ۵ دقیقه).
4) پایین صفحهٔ run، قسمت Artifacts، فایل IranWeapons-jar را دانلود کنید.
5) داخلش iranweapons-1.0.0.jar (بدون -sources و -dev) را بردارید.

نصب در Pojav:
- Minecraft 1.16.5 با Fabric Loader + فایل fabric-api-0.42.0+1.16.jar
- jar مود را هم در پوشهٔ mods کنار fabric-api بگذارید.

استفاده: /summon iranweapons:shahed136  یا fateh110 یا shahab3  (یا از Spawn Egg در Creative > Misc)
